<div class="sliderclass kad-mobile-slider">
	<div id="imageslider" class="container">
		<div class="videofit">
            <?php global $pinnacle; echo $pinnacle['mobile_video_embed'];?>
        </div>
    </div><!--Container-->
</div><!--feat-->