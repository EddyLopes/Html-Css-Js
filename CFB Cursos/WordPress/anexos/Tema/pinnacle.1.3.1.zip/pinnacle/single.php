	<?php get_header(); ?>
			<?php get_template_part('templates/content', 'single'); ?>
			<?php get_sidebar(); ?>
	    	</div><!-- /.row-->
		</div><!-- /.content -->
	</div><!-- /.wrap -->
	<?php get_footer(); ?>