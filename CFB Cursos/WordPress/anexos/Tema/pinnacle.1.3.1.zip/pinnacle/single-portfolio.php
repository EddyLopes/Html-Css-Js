	<?php get_header(); ?>
			<?php get_template_part('templates/content', 'singleportfolio'); ?>
			<?php get_sidebar(); ?>
      		</div><!-- /.row-->
    	</div><!-- /.content -->
  	</div><!-- /.wrap -->
  	<?php get_footer(); ?>